'use strict';

angular.module('myApp.home', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/home', {
    templateUrl: 'home/home.html',
    controller: 'HomeCtrl'
  });
}])

.controller('HomeCtrl', ['$scope','$http', function($scope,$http) {
	$http.get('home/products.json').success(function(response){
		$scope.items = response;

	});

	$scope.addItemToForm = function(){
		// if($scope.itemName){var name=$scope.itemName;} else{var name = null;}
		// if($scope.itemDescription){var description = $scope.itemDescription; }else{var description = null; }
		// if($scope.price){var price = $scope.itemPrice; } else {var price=0;}

		$scope.items = $scope.items.concat([
			{name: $scope.itemName, description: $scope.itemDescription, price: $scope.itemPrice}
		]);

	}

	$scope.removeItem = function(item){
		// console.log("remove item");
		var index = $scope.items.indexOf(item);
		$scope.items.splice(index, 1);
	}

}])

.directive('listDisplay',[function(){
	return {
		restrict : 'E',
		templateUrl: 'home/listDisplay.html'
	};
}])
;